import numpy as np
import talib
from typing import List, Dict, Tuple
import logging
from data_models import Candle

logger = logging.getLogger('FuturesBot')

class TechnicalIndicators:
    # Bộ nhớ cache cho tính toán chỉ báo
    _cache = {}
    _cache_size = 1000
    
    @classmethod
    def calculate_ema(cls, data: List[float], period: int) -> List[float]:
        """Tính đường EMA"""
        if len(data) < period:
            return []
        key = ("ema", period, len(data))
        if key in cls._cache:
            return cls._cache[key]
        ema = talib.EMA(np.array(data, dtype=float), timeperiod=period)
        cls._cache[key] = ema.tolist()
        # Giữ cache không vượt quá kích thước tối đa
        if len(cls._cache) > cls._cache_size:
            cls._cache.pop(next(iter(cls._cache)))
        return ema.tolist()
    
    @classmethod
    def calculate_rsi(cls, data: List[float], period: int) -> List[float]:
        """Tính chỉ số RSI"""
        if len(data) < period:
            return []
        key = ("rsi", period, len(data))
        if key in cls._cache:
            return cls._cache[key]
        rsi = talib.RSI(np.array(data, dtype=float), timeperiod=period)
        cls._cache[key] = rsi.tolist()
        if len(cls._cache) > cls._cache_size:
            cls._cache.pop(next(iter(cls._cache)))
        return rsi.tolist()
    
    @classmethod
    def calculate_atr(cls, candles: List[Candle], period: int) -> List[float]:
        """Tính chỉ báo ATR"""
        if len(candles) < period:
            return []
        key = ("atr", period, len(candles))
        if key in cls._cache:
            return cls._cache[key]
        highs = np.array([c.high for c in candles], dtype=float)
        lows = np.array([c.low for c in candles], dtype=float)
        closes = np.array([c.close for c in candles], dtype=float)
        atr = talib.ATR(highs, lows, closes, timeperiod=period)
        cls._cache[key] = atr.tolist()
        if len(cls._cache) > cls._cache_size:
            cls._cache.pop(next(iter(cls._cache)))
        return atr.tolist()
    
    @classmethod
    def calculate_macd(cls, data: List[float], fast: int, slow: int, signal: int) -> Tuple[List[float], List[float], List[float]]:
        """Tính MACD và đường tín hiệu"""
        if len(data) < slow:
            return [], [], []
        key = ("macd", fast, slow, signal, len(data))
        if key in cls._cache:
            return cls._cache[key]
        macd, macd_signal, macd_hist = talib.MACD(np.array(data, dtype=float), fastperiod=fast, slowperiod=slow, signalperiod=signal)
        result = (macd.tolist(), macd_signal.tolist(), macd_hist.tolist())
        cls._cache[key] = result
        if len(cls._cache) > cls._cache_size:
            cls._cache.pop(next(iter(cls._cache)))
        return result