import sqlite3
import threading
from typing import Dict, List, Optional
from contextlib import contextmanager
from datetime import datetime
import time
from data_models import Position, Trade, MarketCondition, MarketRegime

class DatabaseManager:
    def __init__(self, db_path='trading_bot.db'):
        self.db_path = db_path
        # Sử dụng khóa threading để đảm bảo an toàn khi truy cập đa luồng
        self._lock = threading.Lock()
        # Kết nối và khởi tạo bảng nếu chưa có
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Bảng lưu lịch sử giao dịch
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    id TEXT PRIMARY KEY,
                    symbol TEXT,
                    side TEXT,
                    size REAL,
                    entry_price REAL,
                    exit_price REAL,
                    pnl REAL,
                    pnl_percent REAL,
                    timestamp INTEGER,
                    duration REAL,
                    fee REAL,
                    slippage REAL,
                    strategy TEXT,
                    exit_reason TEXT
                )
            """)
            # Bảng lưu trạng thái thị trường (nếu cần)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS market_conditions (
                    timestamp INTEGER,
                    symbol TEXT,
                    volatility REAL,
                    trend_strength REAL,
                    volume_ratio REAL,
                    market_regime TEXT
                )
            """)
            conn.commit()

    @contextmanager
    def _get_connection(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        try:
            yield conn
        finally:
            conn.commit()
            conn.close()

    def save_trade(self, trade: Trade):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO trades (id, symbol, side, size, entry_price, exit_price, pnl, pnl_percent, timestamp, duration, fee, slippage, strategy, exit_reason)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    trade.id, trade.symbol, trade.side.value, trade.size, trade.entry_price, trade.exit_price,
                    trade.pnl, trade.pnl_percent, trade.timestamp, trade.duration, trade.fee, trade.slippage,
                    trade.strategy, trade.exit_reason
                ))

    def save_market_condition(self, timestamp: int, symbol: str, mc: MarketCondition):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO market_conditions (timestamp, symbol, volatility, trend_strength, volume_ratio, market_regime)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    timestamp, symbol, mc.volatility, mc.trend_strength, mc.volume_ratio, mc.market_regime.value
                ))

    def get_trade_history(self, limit: int = 100) -> List[Trade]:
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM trades ORDER BY timestamp DESC LIMIT ?", (limit,))
                rows = cursor.fetchall()
                trades = []
                for row in rows:
                    trade = Trade(
                        id=row[0],
                        symbol=row[1],
                        side=PositionSide[row[2]],
                        size=row[3],
                        entry_price=row[4],
                        exit_price=row[5],
                        pnl=row[6],
                        pnl_percent=row[7],
                        timestamp=row[8],
                        duration=row[9],
                        fee=row[10],
                        slippage=row[11],
                        strategy=row[12],
                        exit_reason=row[13]
                    )
                    trades.append(trade)
                return trades