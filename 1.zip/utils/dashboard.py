import threading
import logging
from flask import Flask, jsonify, render_template
from config import Config
logger = logging.getLogger('FuturesBot')

class DashboardServer:
    def __init__(self, config: Config, bot: 'FuturesTradingBot'):
        self.config = config
        self.bot = bot
        self.app = Flask(__name__)
        self.thread = None
        
        @self.app.route('/')
        def index():
            # Trang hiển thị thông tin chung
            return jsonify({"message": "Futures Trading Bot Dashboard"})
        
        @self.app.route('/status')
        def status():
            # Trả về trạng thái bot và các vị thế hiện tại
            positions = {
                symbol: {
                    "side": pos.side.value,
                    "size": pos.size,
                    "entry_price": pos.entry_price,
                    "stop_loss": pos.stop_loss,
                    "take_profit": pos.take_profit
                }
                for symbol, pos in self.bot.active_positions.items()
            }
            return jsonify({
                "running": self.bot.running,
                "equity": self.bot.exchange.equity,
                "active_positions": positions
            })
        
        @self.app.route('/metrics')
        def metrics():
            # Trả về các chỉ số hiệu suất (nếu có)
            return jsonify({
                "daily_trade_count": self.bot.risk_manager.daily_trade_count,
                "current_drawdown_pct": self.bot.risk_manager.current_drawdown,
                "consecutive_losses": self.bot.risk_manager.consecutive_losses
            })
        
    def start(self):
        if not self.thread:
            self.thread = threading.Thread(target=self.app.run, kwargs={"port": self.config.general.dashboard_port})
            self.thread.daemon = True
            self.thread.start()
            logger.info(f"Dashboard started on port {self.config.general.dashboard_port}")