import asyncio
import sys
import logging
from config import Config
from futures_trading_bot import FuturesTradingBot

# Thiết lập ghi log
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('futures_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('FuturesBot')

config = Config()
    # Chuyển định dạng các cặp giao dịch thành 'BASE/QUOTE' (thêm dấu '/') nếu chưa có
    standardized_symbols = []
    for sym in config.trading.symbols:
        sym = sym.strip()
        if '/' not in sym:
            if sym.endswith('USDT') or sym.endswith('USDC') or sym.endswith('BUSD'):
                base = sym[:-4]
                quote = sym[-4:]
                sym = base + '/' + quote
            elif sym.endswith('USD'):
                base = sym[:-3]
                quote = sym[-3:]
                sym = base + '/' + quote
        standardized_symbols.append(sym)
    config.trading.symbols = standardized_symbols

async def main():
    # Kiểm tra có chạy backtest hay không
    if len(sys.argv) > 1 and sys.argv[1] == 'backtest':
        # Chạy chế độ backtest
        symbol = sys.argv[2] if len(sys.argv) > 2 else config.trading.symbols[0]
        
        # (Backtest) Tải dữ liệu lịch sử - hiện chưa được triển khai
        print(f"Backtest mode for {symbol} - historical data loading not implemented")
        return
    
    # Chạy bot giao dịch trực tiếp
    bot = FuturesTradingBot(config)
    await bot.run()

if __name__ == "__main__":
    asyncio.run(main())