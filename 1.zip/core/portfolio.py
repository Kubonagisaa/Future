import numpy as np
from typing import List, Dict, Any, Tuple
import logging
from config import Config
from data_models import Candle, Position, PortfolioItem
from utils.indicators import TechnicalIndicators
from core.exchange import FuturesExchange

logger = logging.getLogger('FuturesBot')

class PortfolioManager:
    def __init__(self, config: Config, exchange: FuturesExchange):
        self.config = config
        self.exchange = exchange
        self.weights: Dict[str, float] = {}
        self.correlations: Dict[Tuple[str, str], float] = {}
        self.volatilities: Dict[str, float] = {}

    async def update_portfolio_metrics(self, all_candles: Dict[str, List[Candle]]) -> None:
        """Cập nhật các chỉ số danh mục (tương quan và biến động)"""
        returns = {}
        volatilities = {}
        
        # Tính toán lợi nhuận và độ biến động cho mỗi cặp
        for symbol, candles in all_candles.items():
            if len(candles) >= 20:
                # Tính toán lợi nhuận (return) dựa trên giá đóng cửa
                prices = [c.close for c in candles]
                rets = []
                for i in range(1, len(prices)):
                    if prices[i-1] != 0:
                        rets.append((prices[i] - prices[i-1]) / prices[i-1])
                if rets:
                    returns[symbol] = rets
                    volatilities[symbol] = float(np.std(rets) * 100)
        
        # Tính toán tương quan giữa các cặp
        symbols = list(returns.keys())
        for i in range(len(symbols)):
            for j in range(i+1, len(symbols)):
                s1, s2 = symbols[i], symbols[j]
                if len(returns[s1]) == len(returns[s2]) and len(returns[s1]) > 1:
                    corr = float(np.corrcoef(returns[s1], returns[s2])[0, 1])
                else:
                    corr = 0.0
                self.correlations[(s1, s2)] = corr
        
        # Lưu lại độ biến động
        for symbol, vol in volatilities.items():
            self.volatilities[symbol] = vol