import asyncio
import time
from datetime import datetime
import signal
import sys
import math
from typing import Dict, List, Any
import logging
from config import Config
from core.exchange import FuturesExchange
from core.strategy import create_strategy
from core.risk_manager import RiskManager
from core.portfolio import PortfolioManager
from utils.notifier import TelegramNotifier
from data_models import Position, Order, Trade, PositionSide, MarketCondition, Candle
from utils.database import DatabaseManager
from utils.dashboard import DashboardServer

# Thiết lập logger cho module này. Nếu module được nhập nhiều lần,
# logging.getLogger sẽ trả về cùng một logger theo tên.
logger = logging.getLogger('FuturesBot')

class FuturesTradingBot:
    def __init__(self, config: Config):
        self.config = config
        self.notifier = TelegramNotifier(config)
        self.exchange = FuturesExchange(config, self.notifier)
        self.strategy = create_strategy(config)
        self.risk_manager = RiskManager(config, self.exchange)
        self.portfolio_manager = PortfolioManager(config, self.exchange)
        # (Đã loại bỏ thành phần sentiment analyzer do chưa triển khai)
        # (Đã loại bỏ PerformanceTracker do chưa triển khai)
        self.dashboard = DashboardServer(config, self)
        self.running = False
        self.active_positions = {}
        self.pending_orders = {}
        self.last_stop_loss_time = 0
        self.stop_loss_cooldown = 30 * 60  # 30 phút tạm ngừng sau khi dừng lỗ

        self.last_daily_report = 0
        self.daily_report_interval = 24 * 60 * 60  # 24 giờ

        # Khởi tạo DatabaseManager nếu tính năng lưu dữ liệu được bật. Một số
        # phương thức trong bot sử dụng self.db; vì vậy thuộc tính này luôn
        # tồn tại (có thể là None nếu không dùng database) để tránh lỗi
        # AttributeError.
        if self.config.general.use_database:
            self.db: DatabaseManager | None = DatabaseManager()
        else:
            self.db = None
        
    async def initialize(self):
        # Đặt đòn bẩy cho tất cả các cặp
        for symbol in self.config.trading.symbols:
            await self.exchange.set_leverage(symbol, self.config.trading.max_leverage)
        # Load thông tin thị trường để lấy giới hạn và đơn vị khối lượng
        await self.exchange.load_market_info()
        
        # Thiết lập equity ban đầu
        self.exchange.equity = self.exchange.initial_balance
        
        # Tải các vị thế từ cơ sở dữ liệu nếu có
        if self.config.general.use_database:
            self.active_positions = {}
            # Giả lập: chưa triển khai logic tải từ DB
            # (có thể thêm logic load positions từ DatabaseManager nếu cần)
        
    async def run(self):
        self.running = True
        logger.info("Starting futures trading bot")
        
        # Xử lý tín hiệu dừng (Ctrl+C)
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        await self.initialize()
        
        try:
            while self.running:
                await self.trading_cycle()
                await asyncio.sleep(self.config.general.update_interval)
                
                # Gửi báo cáo hằng ngày nếu cần
                await self.send_daily_report()
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
            await self.notifier.send_message(f"Bot stopped due to error: {str(e)}")
            await self.shutdown()
    
    async def trading_cycle(self):
        try:
            # Áp dụng phí funding (cho chế độ giả lập)
            await self.exchange.apply_funding()
            
            # Cập nhật equity
            await self.exchange.update_equity()
            
            # Cập nhật risk manager
            self.risk_manager.update_drawdown(self.exchange.equity)
            
            # Kiểm tra có thể giao dịch hay không
            if not self.risk_manager.can_trade():
                # Nếu chạm ngưỡng dừng giao dịch, tắt bot
                equity_drawdown = (self.exchange.initial_balance - self.exchange.equity) / self.exchange.initial_balance * 100
                if equity_drawdown >= self.config.risk.max_equity_drawdown:
                    await self.notifier.notify_shutdown(f"Max equity drawdown reached: {equity_drawdown:.2f}%", self.exchange.equity)
                    self.running = False
                return
            
            # Lấy dữ liệu thị trường cho tất cả các cặp
            all_candles = {}
            for symbol in self.config.trading.symbols:
                candles = await self.exchange.get_ohlcv(symbol, self.config.trading.timeframe, 100)
                if candles:
                    all_candles[symbol] = candles
                    
                    # Kiểm tra điều kiện dừng khẩn cấp (circuit breaker)
                    await self.exchange.check_circuit_breaker(symbol, candles)
                    
                    # Kiểm tra điều kiện biến động mạnh
                    if len(candles) >= 2:
                        current_price = candles[-1].close
                        previous_price = candles[-2].close
                        if self.risk_manager.check_extreme_conditions(current_price, previous_price):
                            await self.notifier.notify_shutdown(f"Extreme volatility detected: {abs(current_price - previous_price)/previous_price*100:.2f}%", self.exchange.equity)
                            self.running = False
                            return
            
            # Cập nhật các chỉ số danh mục
            await self.portfolio_manager.update_portfolio_metrics(all_candles)
            
            # Tạo tín hiệu cho tất cả các cặp
            signals = {}
            market_conditions = {}
            
            for symbol, candles in all_candles.items():
                if candles and len(candles) > 20:
                    signal_data = self.strategy.generate_signal(candles)
                    signals[symbol] = signal_data
                    
                    # Phân tích điều kiện thị trường
                    market_condition = self.strategy.analyze_market_condition(candles)
                    market_conditions[symbol] = market_condition
                    
                    # Lưu trạng thái thị trường vào cơ sở dữ liệu nếu bật
                    if self.config.general.use_database:
                        self.db.save_market_condition(int(time.time() * 1000), symbol, market_condition)
            
            # Lấy các vị thế hiện tại
            current_positions = {}
            self.active_positions = {}
            for symbol in self.config.trading.symbols:
                position = await self.exchange.get_position(symbol)
                if position:
                    current_positions[symbol] = position
                    self.active_positions[symbol] = position
            
            # Tính toán phân bổ danh mục
            portfolio_allocations = self.portfolio_manager.get_portfolio_allocation(signals)
            
            # Xử lý cho từng cặp
            for symbol in self.config.trading.symbols:
                if symbol in all_candles and symbol in signals:
                    candles = all_candles[symbol]
                    signal_data = signals[symbol]
                    
                    # Kiểm tra các lệnh mở cho cặp này
                    await self.exchange.check_open_orders(symbol)
                    
                    # Xử lý vị thế nếu đang có
                    if symbol in current_positions:
                        await self.manage_position(current_positions[symbol], candles, market_conditions[symbol])
                    else:
                        # Nếu đang tạm ngừng sau khi dừng lỗ
                        current_time = time.time()
                        if current_time - self.last_stop_loss_time < self.stop_loss_cooldown:
                            logger.info(f"In cooldown period after stop loss for {symbol}")
                            continue
                        
                        # Kiểm tra giới hạn danh mục
                        if not self.portfolio_manager.should_enter_trade(symbol, signals, current_positions):
                            continue
                        
                        # Không có vị thế, kiểm tra mở mới
                        if signal_data["signal"] != "HOLD" and signal_data["confidence"] > 0.3:
                            # Lấy trọng số danh mục cho cặp này
                            portfolio_weight = portfolio_allocations.get(symbol, 1.0)
                            
                            await self.enter_position(signal_data, candles, portfolio_weight)
        
        except Exception as e:
            logger.error(f"Error in trading cycle: {e}")
    
    async def enter_position(self, signal_data: Dict, candles: List[Candle], portfolio_weight: float = 1.0):
        symbol = signal_data.get('symbol', self.config.trading.symbols[0])
        side = PositionSide.LONG if signal_data["signal"] == "LONG" else PositionSide.SHORT
        current_price = signal_data["price"]
        atr = signal_data["atr"]
        
        # Tính toán khối lượng vị thế với phân bổ danh mục
        position_size = self.risk_manager.calculate_position_size(current_price, atr, portfolio_weight)
        
        if position_size <= 0:
            logger.warning(f"Position size is zero or negative for {symbol}")
            return
        
        # Tính toán đòn bẩy thích ứng
        leverage = self.risk_manager.calculate_adaptive_leverage(atr, current_price)
        
        # Tính toán stop loss và take profit
        if side == PositionSide.LONG:
            stop_loss = current_price - (atr * self.config.risk.stop_loss_atr)
            take_profit = current_price + (atr * self.config.risk.take_profit_atr)
        else:  # SHORT
            stop_loss = current_price + (atr * self.config.risk.stop_loss_atr)
            take_profit = current_price - (atr * self.config.risk.take_profit_atr)
        
        # Với chiến lược scale-in, bắt đầu với một phần vị thế
        scale_in_factor = 1.0 / self.config.order.scale_in_levels
        initial_size = position_size * scale_in_factor
        
        # Kiểm tra khối lượng tối thiểu và làm tròn khối lượng lệnh theo bước nhảy sàn
        market = self.exchange.exchange.markets.get(symbol) if hasattr(self.exchange, 'exchange') else None
        if market:
            min_qty = None
            step_size = None
            for f in market['info'].get('filters', []):
                if f.get('filterType') == 'LOT_SIZE':
                    min_qty = float(f.get('minQty', 0))
                    step_size = float(f.get('stepSize', 0))
                    break
            if step_size:
                initial_size = math.floor(initial_size / step_size) * step_size
            if min_qty and initial_size < min_qty:
                if initial_size <= 0:
                    logger.warning(f"Khối lượng tính toán {initial_size:.6f} nhỏ hơn tối thiểu {min_qty:.6f} cho {symbol}")
                    return
                else:
                    logger.info(f"Điều chỉnh khối lượng lệnh của {symbol} lên tối thiểu {min_qty}")
                    initial_size = min_qty

        # Tạo lệnh
        order = await self.exchange.create_order(
            symbol=symbol,
            order_type=OrderType.MARKET,
            side=side,
            amount=initial_size,
            params={
                'leverage': leverage,
                'stopLoss': stop_loss,
                'takeProfit': take_profit,
                'entry_reason': self.config.strategy.strategy_type
            }
        )
        
        if order:
            logger.info(f"Entered {side.value} position for {symbol}, size: {initial_size}, leverage: {leverage}")
            await self.notifier.notify_trade(side, symbol, initial_size, current_price, self.config.strategy.strategy_type)
            
            # Cập nhật số lệnh trong ngày
            self.risk_manager.daily_trade_count += 1
            
            # Tạo đối tượng Position và lưu vào danh sách vị thế
            position = Position(
                symbol=symbol,
                side=side,
                size=initial_size,
                entry_price=current_price,
                leverage=leverage,
                stop_loss=stop_loss,
                take_profit=take_profit,
                timestamp=int(time.time() * 1000),
                entry_reason=self.config.strategy.strategy_type,
                last_funding_time=int(time.time()),
                scale_in_level=1,
                scale_out_level=0
            )
            self.exchange.positions[symbol] = position
            self.active_positions[symbol] = position

            # Lưu lại cấp độ scale-in
            if symbol in self.exchange.positions:
                self.exchange.positions[symbol].scale_in_level = 1
    
    async def manage_position(self, position: Position, candles: List[Candle], market_condition: MarketCondition):
        symbol = position.symbol
        current_price = candles[-1].close if candles else await self.exchange.get_current_price(symbol)
        atr = TechnicalIndicators.calculate_atr(candles, self.config.strategy.atr_period)[-1] if candles else 0
        
        # Cập nhật trailing stop và take profit
        new_stop_loss = self.risk_manager.calculate_dynamic_stop_loss(position, current_price, atr)
        new_take_profit = self.risk_manager.calculate_dynamic_take_profit(position, current_price, atr)
        
        # Cập nhật vị thế nếu stop loss hoặc take profit thay đổi
        if new_stop_loss != position.stop_loss or new_take_profit != position.take_profit:
            position.stop_loss = new_stop_loss
            position.take_profit = new_take_profit
            
            # Lưu vào cơ sở dữ liệu nếu bật
            if self.config.general.use_database:
                self.db.save_position(position)
                
            # Thông báo về cập nhật trailing
            await self.notifier.notify_trailing_update(symbol, new_stop_loss, new_take_profit)
        
        # Kiểm tra chạm stop loss hoặc take profit
        if position.side == PositionSide.LONG:
            if current_price <= position.stop_loss:
                await self.exit_position(position, current_price, "Stop Loss")
                self.last_stop_loss_time = time.time()
                
                # Đảo chiều tự động nếu được cấu hình
                if self.config.order.auto_reverse:
                    await asyncio.sleep(1)  # Dừng một chút
                    signal_data = {
                        "signal": "SHORT",
                        "confidence": 0.5,
                        "atr": atr,
                        "price": current_price
                    }
                    await self.enter_position(signal_data, candles, 1.0)
                return
            elif current_price >= position.take_profit:
                # Chốt lời từng phần hoặc thoát lệnh hoàn toàn
                if position.scale_out_level < self.config.order.scale_out_levels - 1:
                    # Chốt lời một phần
                    scale_out_size = position.size / (self.config.order.scale_out_levels - position.scale_out_level)
                    await self.exit_partial_position(position, scale_out_size, current_price, "Partial Take Profit")
                    position.scale_out_level += 1
                else:
                    # Thoát lệnh hoàn toàn
                    await self.exit_position(position, current_price, "Take Profit")
                return
        else:  # SHORT
            if current_price >= position.stop_loss:
                await self.exit_position(position, current_price, "Stop Loss")
                self.last_stop_loss_time = time.time()
                
                # Đảo chiều tự động nếu được cấu hình
                if self.config.order.auto_reverse:
                    await asyncio.sleep(1)  # Dừng một chút
                    signal_data = {
                        "signal": "LONG",
                        "confidence": 0.5,
                        "atr": atr,
                        "price": current_price
                    }
                    await self.enter_position(signal_data, candles, 1.0)
                return
            elif current_price <= position.take_profit:
                # Chốt lời từng phần hoặc thoát lệnh hoàn toàn
                if position.scale_out_level < self.config.order.scale_out_levels - 1:
                    # Chốt lời một phần
                    scale_out_size = position.size / (self.config.order.scale_out_levels - position.scale_out_level)
                    await self.exit_partial_position(position, scale_out_size, current_price, "Partial Take Profit")
                    position.scale_out_level += 1
                else:
                    # Thoát lệnh hoàn toàn
                    await self.exit_position(position, current_price, "Take Profit")
                return

    async def exit_partial_position(self, position: Position, amount: float, exit_price: float, reason: str):
        # Đóng một phần vị thế
        symbol = position.symbol
        side = position.side
        # Tạo lệnh đóng một phần
        success = await self.exchange.close_position(symbol, side, amount, reason)
        if success:
            position.size -= amount
            # Cập nhật stop_loss_time nếu là stop loss
            if reason.lower().startswith("stop"):
                self.last_stop_loss_time = time.time()
            logger.info(f"Partially closed {amount} of {symbol} position due to {reason}")

    async def exit_position(self, position: Position, exit_price: float, reason: str):
        success = await self.exchange.close_position(
            position.symbol, position.side, position.size, reason
        )
        
        if success:
            # Tính PnL
            if position.side == PositionSide.LONG:
                pnl = (exit_price - position.entry_price) * position.size
            else:  # SHORT
                pnl = (position.entry_price - exit_price) * position.size
            
            pnl_percent = (pnl / (position.size * position.entry_price)) * 100 * position.leverage
            
            # Đối với chế độ giả lập, tính phí và trượt giá
            fee = (position.size * exit_price) * self.config.order.taker_fee
            slippage = exit_price * self.config.order.slippage
            
            # Tạo đối tượng Trade
            trade = Trade(
                id=f"trade_{int(time.time() * 1000)}",
                symbol=position.symbol,
                side=position.side,
                size=position.size,
                entry_price=position.entry_price,
                exit_price=exit_price,
                pnl=pnl,
                pnl_percent=pnl_percent,
                timestamp=int(time.time() * 1000),
                duration=(time.time() * 1000 - position.timestamp) / 1000,
                fee=fee,
                slippage=slippage,
                strategy=position.entry_reason,
                exit_reason=reason
            )
            
            # Cập nhật log trade (đã bỏ cập nhật vào PerformanceTracker)
            logger.info(f"Trade closed: {position.symbol} {position.side.value}, PnL: {pnl:.2f}, Reason: {reason}")
            if self.config.general.use_database:
                self.db.save_trade(trade)
            # Xóa vị thế khỏi danh sách hoạt động
            self.active_positions.pop(position.symbol, None)
    
    async def send_daily_report(self):
        current_time = time.time()
        if current_time - self.last_daily_report >= self.daily_report_interval:
            self.last_daily_report = current_time
            
            # Lấy các giao dịch trong ngày từ cơ sở dữ liệu
            trades = self.db.get_trade_history(100) if self.db else []
            today = datetime.now().date()
            today_trades = [t for t in trades if datetime.fromtimestamp(t.timestamp/1000).date() == today]
            
            # Tính toán PnL trong ngày và tỷ lệ thắng
            daily_pnl = sum(t.pnl for t in today_trades)
            winning_trades = [t for t in today_trades if t.pnl >= 0]
            win_rate = len(winning_trades) / len(today_trades) * 100 if today_trades else 0
            
            await self.notifier.notify_daily_report(len(today_trades), daily_pnl, win_rate)
    
    def signal_handler(self, signum, frame):
        logger.info(f"Received signal {signum}, shutting down")
        self.running = False
    
    async def shutdown(self):
        logger.info("Shutting down bot")
        
        # Đóng tất cả các vị thế
        for symbol, position in list(self.active_positions.items()):
            await self.exit_position(position, position.entry_price, "Shutdown")
        # Hủy tất cả các lệnh đang mở nếu có
        for order_id, order in list(self.exchange.open_orders.items()):
            try:
                await self.exchange.exchange.cancel_order(order_id, order.symbol)
            except Exception as e:
                logger.error(f"Failed to cancel order {order_id}: {e}")
        self.running = False
        await self.notifier.send_message("Bot stopped.")