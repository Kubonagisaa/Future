from typing import List, Dict, Any, Optional
import numpy as np
from scipy.stats import linregress
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib
import logging
from config import Config
from data_models import Candle, MarketCondition, MarketRegime
from utils.indicators import TechnicalIndicators

logger = logging.getLogger('FuturesBot')

class MLSignalPredictor:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.is_trained = False
        self.feature_cache = {}  # Cache for calculated features
        
    def prepare_features(self, candles: List[Candle]) -> Optional[np.ndarray]:
        """Chuẩn bị đặc trưng cho mô hình ML từ dữ liệu nến"""
        if len(candles) < 50:
            return None
            
        # Kiểm tra cache trước
        cache_key = f"{candles[-1].timestamp}_{len(candles)}"
        if cache_key in self.feature_cache:
            return self.feature_cache[cache_key]
            
        closes = np.array([c.close for c in candles])
        opens = np.array([c.open for c in candles])
        highs = np.array([c.high for c in candles])
        lows = np.array([c.low for c in candles])
        volumes = np.array([c.volume for c in candles])
        
        # Tính các chỉ báo kỹ thuật làm đặc trưng đầu vào
        rsi = np.array(TechnicalIndicators.calculate_rsi(closes.tolist(), 14))
        macd, signal, hist = TechnicalIndicators.calculate_macd(closes.tolist(), 12, 26, 9)
        macd = np.array(macd)
        
        # Biến động giá
        price_change_1 = np.diff(closes) / closes[:-1] * 100
        price_change_1 = np.concatenate(([0], price_change_1))
        
        price_change_5 = (closes[5:] - closes[:-5]) / closes[:-5] * 100
        price_change_5 = np.concatenate(([0] * 5, price_change_5))
        
        # Biến động khối lượng
        volume_change = np.diff(volumes) / (volumes[:-1] + 1e-6) * 100
        volume_change = np.concatenate(([0], volume_change))
        
        # Tập hợp các đặc trưng
        features = np.column_stack([
            closes, opens, highs, lows, volumes,
            rsi, macd, signal, hist,
            price_change_1, price_change_5,
            volume_change
        ])
        
        # Chuẩn hoá các đặc trưng
        features = np.nan_to_num(features)  # xử lý NaN nếu có
        features_scaled = self.scaler.fit_transform(features)
        
        # Cập nhật cache
        self.feature_cache[cache_key] = features_scaled[-1].reshape(1, -1)
        
        return features_scaled[-1].reshape(1, -1)
    
    def train(self, X: np.ndarray, y: np.ndarray):
        # Huấn luyện mô hình Random Forest cho tín hiệu
        self.model = RandomForestClassifier(n_estimators=100)
        self.model.fit(X, y)
        self.is_trained = True
        logger.info("ML model trained")

    def predict(self, X: np.ndarray) -> np.ndarray:
        # Dự đoán tín hiệu (đầu ra xác suất)
        if not self.is_trained or self.model is None:
            raise ValueError("Model is not trained yet")
        return self.model.predict_proba(X)
    
    def save_model(self, filename="ml_model.pkl"):
        # Lưu mô hình ML ra file
        if self.model:
            joblib.dump((self.model, self.scaler), filename)
            logger.info(f"ML model saved to {filename}")
    
    def load_model(self, filename="ml_model.pkl"):
        # Tải mô hình ML từ file
        try:
            self.model, self.scaler = joblib.load(filename)
            self.is_trained = True
            logger.info(f"ML model loaded from {filename}")
        except FileNotFoundError:
            logger.warning(f"No saved model found at {filename}")

class BaseStrategy:
    def __init__(self, config: Config):
        self.config = config
        self.indicators = TechnicalIndicators()
        self.name = self.__class__.__name__
    
    def generate_signal(self, candles: List[Candle]) -> Dict[str, Any]:
        raise NotImplementedError("Strategy must implement generate_signal method")
    
    def analyze_market_condition(self, candles: List[Candle]) -> MarketCondition:
        """Phân tích điều kiện thị trường hiện tại"""
        if len(candles) < 50:
            return MarketCondition(
                volatility=0, 
                trend_strength=0, 
                volume_ratio=0, 
                market_regime=MarketRegime.UNKNOWN
            )
        
        closes = [c.close for c in candles]
        volumes = [c.volume for c in candles]
        
        # Tính độ biến động (ATR theo phần trăm giá)
        atr = self.indicators.calculate_atr(candles, self.config.strategy.atr_period)
        current_atr = atr[-1] if atr and len(atr) > 0 else 0
        volatility = (current_atr / closes[-1]) * 100 if closes[-1] > 0 else 0
        
        # Tính độ mạnh xu thế (độ dốc của hồi quy tuyến tính)
        if len(closes) >= 20:
            x = np.arange(len(closes[-20:]))
            y = np.array(closes[-20:])
            slope, _, r_value, _, _ = linregress(x, y)
            trend_strength = abs(slope / y[0]) * 100  # Normalize thành %
            r_squared = r_value ** 2  # Hệ số xác định (R^2)
        else:
            trend_strength = 0
            r_squared = 0
        
        # Tính tỷ lệ khối lượng (khối lượng hiện tại so với MA)
        if len(volumes) >= 20:
            volume_ma = sum(volumes[-20:-1]) / 19 if len(volumes) >= 20 else volumes[-1]
            volume_ratio = volumes[-1] / volume_ma if volume_ma > 0 else 1
        else:
            volume_ratio = 1
        
        # Xác định xu thế thị trường
        if volatility > 2.0:
            market_regime = MarketRegime.HIGH_VOLATILITY
        elif trend_strength > 1.0 and r_squared > 0.6:
            market_regime = MarketRegime.TRENDING
        elif trend_strength < 0.2 and volatility < 0.5:
            market_regime = MarketRegime.LOW_VOLATILITY
        else:
            market_regime = MarketRegime.MEAN_REVERTING
        
        return MarketCondition(
            volatility=volatility,
            trend_strength=trend_strength,
            volume_ratio=volume_ratio,
            market_regime=market_regime
        )

class EmaRsiAtrStrategy(BaseStrategy):
    def generate_signal(self, candles: List[Candle]) -> Dict[str, Any]:
        if len(candles) < max(self.config.strategy.ema_slow, self.config.strategy.rsi_period, self.config.strategy.atr_period) + 1:
            return {"signal": "HOLD", "confidence": 0, "atr": 0, "price": 0, "strategy": self.name}
        
        # Lấy giá đóng cửa
        closes = [candle.close for candle in candles]
        # Tính toán các chỉ báo
        ema_fast = self.indicators.calculate_ema(closes, self.config.strategy.ema_fast)
        ema_slow = self.indicators.calculate_ema(closes, self.config.strategy.ema_slow)
        rsi = self.indicators.calculate_rsi(closes, self.config.strategy.rsi_period)
        atr = self.indicators.calculate_atr(candles, self.config.strategy.atr_period)
        
        current_price = closes[-1]
        current_rsi = rsi[-1] if rsi else 0
        current_atr = atr[-1] if atr else 0
        ema_fast_current = ema_fast[-1] if ema_fast else 0
        ema_slow_current = ema_slow[-1] if ema_slow else 0
        
        signal = "HOLD"
        confidence = 0
        
        if ema_fast_current > ema_slow_current and current_rsi < self.config.strategy.rsi_oversold:
            signal = "LONG"
            # Độ tự tin dựa trên RSI so với ngưỡng quá bán và độ mạnh giao cắt EMA
            rsi_confidence = (self.config.strategy.rsi_oversold - current_rsi) / self.config.strategy.rsi_oversold
            ema_confidence = (ema_fast_current - ema_slow_current) / ema_slow_current * 100
            confidence = min(0.9, (rsi_confidence + ema_confidence / 10) / 2)
        elif ema_fast_current < ema_slow_current and current_rsi > self.config.strategy.rsi_overbought:
            signal = "SHORT"
            rsi_confidence = (current_rsi - self.config.strategy.rsi_overbought) / (100 - self.config.strategy.rsi_overbought)
            ema_confidence = (ema_slow_current - ema_fast_current) / ema_fast_current * 100
            confidence = min(0.9, (rsi_confidence + ema_confidence / 10) / 2)
        
        return {"signal": signal, "confidence": max(confidence, 0), "atr": current_atr, "price": current_price, "strategy": self.name}

# Các chiến lược khác sẽ tương tự với các cải tiến (ScalpingStrategy, MeanReversionStrategy, MultiIndicatorStrategy, AIMLStrategy, EnsembleStrategy)
def create_strategy(config: Config) -> BaseStrategy:
    strategy_map = {
        "EMA_RSI_ATR": EmaRsiAtrStrategy,
        # "SCALPING": ScalpingStrategy,
        # "MEAN_REVERSION": MeanReversionStrategy,
        # "MULTI_INDICATOR": MultiIndicatorStrategy,
        "AI_ML": AIMLStrategy,
        "ENSEMBLE": EnsembleStrategy
    }
    
    strategy_class = strategy_map.get(config.strategy.strategy_type, EmaRsiAtrStrategy)
    return strategy_class(config)

class AIMLStrategy(BaseStrategy):
    def __init__(self, config: Config):
        super().__init__(config)
        self.ml_predictor = MLSignalPredictor()
    
    def generate_signal(self, candles: List[Candle]) -> Dict[str, Any]:
        if not self.ml_predictor.is_trained:
            return {"signal": "HOLD", "confidence": 0, "atr": 0, "price": candles[-1].close if candles else 0, "strategy": self.name}
        
        features = self.ml_predictor.prepare_features(candles)
        if features is None:
            return {"signal": "HOLD", "confidence": 0, "atr": 0, "price": candles[-1].close if candles else 0, "strategy": self.name}
        
        prediction = self.ml_predictor.predict(features)
        # Giả định: mô hình dự đoán [prob_hold, prob_long, prob_short]
        prob_long = prediction[0][1] if prediction.shape[1] > 1 else 0
        prob_short = prediction[0][2] if prediction.shape[1] > 2 else 0
        
        if prob_long > 0.6:
            return {"signal": "LONG", "confidence": prob_long, "atr": 0, "price": candles[-1].close, "strategy": self.name}
        elif prob_short > 0.6:
            return {"signal": "SHORT", "confidence": prob_short, "atr": 0, "price": candles[-1].close, "strategy": self.name}
        else:
            return {"signal": "HOLD", "confidence": 1 - max(prob_long, prob_short), "atr": 0, "price": candles[-1].close, "strategy": self.name}

class EnsembleStrategy(BaseStrategy):
    def __init__(self, config: Config):
        super().__init__(config)
        self.strategy1 = EmaRsiAtrStrategy(config)
        self.strategy2 = AIMLStrategy(config)
    
    def generate_signal(self, candles: List[Candle]) -> Dict[str, Any]:
        sig1 = self.strategy1.generate_signal(candles)
        sig2 = self.strategy2.generate_signal(candles)
        # Kết hợp tín hiệu từ hai chiến lược (giản lược: ưu tiên giữ nếu không đồng nhất)
        if sig1["signal"] == sig2["signal"]:
            return sig1  # nếu cả hai đồng ý
        else:
            return {"signal": "HOLD", "confidence": 0, "atr": sig1["atr"], "price": sig1["price"], "strategy": self.name}