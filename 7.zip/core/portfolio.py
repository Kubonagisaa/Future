import numpy as np
from typing import List, Dict, Any, Tuple
import logging
from config import Config
from data_models import Candle, Position, PortfolioItem
from utils.indicators import TechnicalIndicators
from core.exchange import FuturesExchange

logger = logging.getLogger('FuturesBot')

class PortfolioManager:
    def __init__(self, config: Config, exchange: FuturesExchange):
        self.config = config
        self.exchange = exchange
        self.weights: Dict[str, float] = {}
        self.correlations: Dict[Tuple[str, str], float] = {}
        self.volatilities: Dict[str, float] = {}

    async def update_portfolio_metrics(self, all_candles: Dict[str, List[Candle]]) -> None:
        """Cập nhật các chỉ số danh mục (tương quan và biến động)"""
        returns = {}
        volatilities = {}
        
        # Tính toán lợi nhuận và độ biến động cho mỗi cặp
        for symbol, candles in all_candles.items():
            if len(candles) >= 20:
                # Tính toán lợi nhuận (return) dựa trên giá đóng cửa
                prices = [c.close for c in candles]
                rets = []
                for i in range(1, len(prices)):
                    if prices[i-1] != 0:
                        rets.append((prices[i] - prices[i-1]) / prices[i-1])
                if rets:
                    returns[symbol] = rets
                    volatilities[symbol] = float(np.std(rets) * 100)
        
        # Tính toán tương quan giữa các cặp
        symbols = list(returns.keys())
        for i in range(len(symbols)):
            for j in range(i+1, len(symbols)):
                s1, s2 = symbols[i], symbols[j]
                if len(returns[s1]) == len(returns[s2]) and len(returns[s1]) > 1:
                    corr = float(np.corrcoef(returns[s1], returns[s2])[0, 1])
                else:
                    corr = 0.0
                self.correlations[(s1, s2)] = corr
        
        # Lưu lại độ biến động
        for symbol, vol in volatilities.items():
            self.volatilities[symbol] = vol

    def get_portfolio_allocation(self, signals: Dict[str, Dict[str, Any]]) -> Dict[str, float]:
        """
        Tính toán phân bổ danh mục dựa trên tín hiệu đầu vào.

        Hàm này nhận vào một dict ``signals`` chứa tín hiệu cho từng cặp, trong
        đó mỗi tín hiệu là dict với các khóa ``signal`` và ``confidence``. Nếu
        ``signal`` khác ``HOLD``, chúng ta sẽ phân bổ một tỷ trọng dựa trên
        độ tự tin ``confidence``. Nếu tất cả tín hiệu là ``HOLD``, trả về
        một dict rỗng.

        Trọng số được chuẩn hóa để tổng cộng bằng 1. Nếu ``confidence`` không
        có hoặc bằng 0, chúng ta coi nó bằng 1. Điều này đảm bảo rằng mỗi
        giao dịch tiềm năng đều nhận được trọng số hợp lý.
        """
        weights: Dict[str, float] = {}
        # Lấy các tín hiệu hợp lệ (khác HOLD)
        valid_signals = {s: d for s, d in signals.items() if d.get("signal") != "HOLD"}
        if not valid_signals:
            return weights
        # Tính tổng độ tự tin
        total_confidence = 0.0
        for sym, d in valid_signals.items():
            confidence = d.get("confidence", 1.0)
            # đảm bảo confidence luôn dương
            if confidence <= 0:
                confidence = 1.0
            weights[sym] = confidence
            total_confidence += confidence
        # Chuẩn hóa
        for sym in weights:
            weights[sym] /= total_confidence
        return weights

    def should_enter_trade(self, symbol: str, signals: Dict[str, Dict[str, Any]], current_positions: Dict[str, Position]) -> bool:
        """
        Xác định xem có nên mở vị thế mới cho ``symbol`` hay không.

        Đây là một hàm đơn giản nhằm minh họa logic quản lý danh mục. Chúng ta
        kiểm tra các vị thế hiện tại và tương quan giữa cặp đang xét và các cặp
        đang nắm giữ. Nếu tương quan vượt quá ngưỡng ``max_correlation`` trong
        cấu hình danh mục, chúng ta từ chối mở vị thế để tránh rủi ro tập
        trung quá mức. Nếu không, luôn cho phép mở vị thế.

        :param symbol: Mã cặp cần xem xét
        :param signals: Tín hiệu cho tất cả các cặp
        :param current_positions: Các vị thế đang mở
        :return: True nếu được phép mở lệnh, False ngược lại
        """
        # Nếu không có vị thế nào hiện tại thì luôn cho phép
        if not current_positions:
            return True
        # Kiểm tra tương quan với các cặp đang nắm giữ
        for held_symbol in current_positions.keys():
            # Tránh so sánh một cặp với chính nó
            if symbol == held_symbol:
                continue
            pair = (symbol, held_symbol) if (symbol, held_symbol) in self.correlations else (held_symbol, symbol)
            corr = self.correlations.get(pair)
            if corr is None:
                continue
            # Nếu tương quan vượt ngưỡng tối đa, từ chối
            if abs(corr) > self.config.portfolio.max_correlation:
                logger.info(
                    f"Correlation between {symbol} and {held_symbol} ({corr:.2f}) exceeds max allowed {self.config.portfolio.max_correlation}; skipping trade."
                )
                return False
        return True