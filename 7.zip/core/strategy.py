"""
Compatability module for strategy.

This file simply re-exports all public definitions from the
``strateggy.py`` module. In the original codebase the module name was
misspelled as ``strateggy.py`` but other parts of the application
attempt to import from ``core.strategy``. To avoid ``ModuleNotFoundError``
and require users to rename files, we provide this wrapper.

Note: It's generally better to fix the import statements, but since
changing all import references can be error‑prone, this approach
maintains backwards compatibility.
"""

from .strateggy import *  # noqa: F401,F403