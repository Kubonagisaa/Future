import logging
import numpy as np
from typing import Dict, List
from scipy.stats import norm
from config import Config
from data_models import Position, Candle
from core.exchange import FuturesExchange

logger = logging.getLogger('FuturesBot')

class RiskManager:
    def __init__(self, config: Config, exchange: FuturesExchange):
        self.config = config
        self.exchange = exchange
        self.daily_trade_count = 0
        self.last_equity = exchange.initial_balance
        self.max_equity_reached = exchange.initial_balance
        self.current_drawdown = 0
        self.consecutive_losses = 0
        self.var_cache = {}  # Cache for VaR calculations

    def update_drawdown(self, equity: float) -> None:
        """Cập nhật tính toán mức sụt giảm (drawdown)"""
        self.current_drawdown = (self.max_equity_reached - equity) / self.max_equity_reached * 100
        if equity > self.max_equity_reached:
            self.max_equity_reached = equity

    def can_trade(self) -> bool:
        # Giới hạn số lệnh và mức thua lỗ cho mỗi ngày
        if self.daily_trade_count >= self.config.trading.max_daily_trades:
            logger.warning(f"Max daily trades reached: {self.daily_trade_count}")
            return False
        if self.current_drawdown >= self.config.risk.max_daily_drawdown:
            logger.warning(f"Daily drawdown limit reached: {self.current_drawdown:.2f}%")
            return False
        if self.consecutive_losses >= self.config.risk.max_consecutive_losses:
            logger.warning(f"Max consecutive losses reached: {self.consecutive_losses}")
            return False
        return True

    def check_extreme_conditions(self, current_price: float, previous_price: float) -> bool:
        # Kiểm tra điều kiện thị trường biến động quá mạnh (ví dụ: giá giảm/tăng đột biến)
        change_pct = abs(current_price - previous_price) / previous_price * 100
        return change_pct >= self.config.risk.max_volatility

    def calculate_dynamic_stop_loss(self, position: Position, current_price: float, atr: float) -> float:
        """Tính toán stop loss động với chức năng trailing"""
        if position.side == PositionSide.LONG:
            # Với lệnh LONG, dừng lỗ đặt dưới giá hiện tại
            new_stop = current_price - (atr * self.config.risk.trailing_stop_atr)
            # Chỉ dời stop nếu giá đã di chuyển có lợi cho vị thế
            if new_stop > position.stop_loss or position.stop_loss == 0:
                return new_stop
            else:
                return position.stop_loss
        else:
            # Với lệnh SHORT, dừng lỗ đặt trên giá hiện tại
            new_stop = current_price + (atr * self.config.risk.trailing_stop_atr)
            if new_stop < position.stop_loss or position.stop_loss == 0:
                return new_stop
            else:
                return position.stop_loss

    def calculate_dynamic_take_profit(self, position: Position, current_price: float, atr: float) -> float:
        # Tính toán chốt lời động (có thể sử dụng trailing take profit nếu cần)
        if position.side == PositionSide.LONG:
            return current_price + (atr * self.config.risk.trailing_stop_atr)
        else:
            return current_price - (atr * self.config.risk.trailing_stop_atr)

    def calculate_position_size(self, current_price: float, atr: float, portfolio_weight: float = 1.0) -> float:
        """Tính toán khối lượng lệnh dựa trên tham số rủi ro"""
        risk_amount = self.exchange.equity * (self.config.trading.risk_per_trade / 100.0) * portfolio_weight
        stop_loss_distance = atr * self.config.risk.stop_loss_atr
        
        if stop_loss_distance == 0:
            return 0
            
        position_size = risk_amount / stop_loss_distance
        
        # Điều chỉnh nếu chế độ risk-off bật
        if self.config.general.risk_off_mode:
            position_size *= (self.config.general.risk_off_capital_pct / 100.0)
            
        return position_size

    def calculate_adaptive_leverage(self, atr: float, current_price: float) -> int:
        """Tính toán đòn bẩy thích ứng dựa trên độ biến động"""
        if atr == 0:
            return self.config.trading.min_leverage
            
        vol_pct = atr / current_price * 100
        
        # Giảm đòn bẩy nếu biến động cao
        if vol_pct > 5:
            return self.config.trading.min_leverage
        elif vol_pct < 1:
            return self.config.trading.max_leverage
        else:
            # Nội suy tuyến tính giữa đòn bẩy min và max
            ratio = (5 - vol_pct) / 4
            leverage = self.config.trading.min_leverage + int(
                ratio * (self.config.trading.max_leverage - self.config.trading.min_leverage)
            )
            return max(self.config.trading.min_leverage, min(self.config.trading.max_leverage, leverage))