from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, List, Optional
from datetime import datetime

class PositionSide(Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    FLAT = "FLAT"

class OrderType(Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_MARKET = "STOP_MARKET"
    TAKE_PROFIT = "TAKE_PROFIT"
    TAKE_PROFIT_MARKET = "TAKE_PROFIT_MARKET"
    TRAILING_STOP = "TRAILING_STOP"

class OrderStatus(Enum):
    OPEN = "OPEN"
    FILLED = "FILLED"
    PARTIAL = "PARTIAL"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"

class MarketRegime(Enum):
    TRENDING = "TRENDING"
    MEAN_REVERTING = "MEAN_REVERTING"
    HIGH_VOLATILITY = "HIGH_VOLATILITY"
    LOW_VOLATILITY = "LOW_VOLATILITY"
    UNKNOWN = "UNKNOWN"

@dataclass
class Candle:
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'timestamp': self.timestamp,
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'volume': self.volume
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Candle':
        return cls(
            timestamp=data['timestamp'],
            open=data['open'],
            high=data['high'],
            low=data['low'],
            close=data['close'],
            volume=data['volume']
        )

@dataclass
class Position:
    symbol: str
    side: PositionSide
    size: float
    entry_price: float
    leverage: int
    stop_loss: float
    take_profit: float
    timestamp: int
    entry_reason: str = ""
    last_funding_time: int = 0
    scale_in_level: int = 0
    scale_out_level: int = 0

@dataclass
class Order:
    id: str
    symbol: str
    type: OrderType
    side: PositionSide
    amount: float
    price: float
    status: OrderStatus
    timestamp: int
    params: Dict[str, Any] = field(default_factory=dict)
    filled: float = 0.0
    remaining: float = 0.0

@dataclass
class Trade:
    id: str
    symbol: str
    side: PositionSide
    size: float
    entry_price: float
    exit_price: float
    pnl: float
    pnl_percent: float
    timestamp: int
    duration: float
    fee: float
    slippage: float
    strategy: str
    exit_reason: str

@dataclass
class MarketCondition:
    volatility: float
    trend_strength: float
    volume_ratio: float
    market_regime: MarketRegime
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'volatility': self.volatility,
            'trend_strength': self.trend_strength,
            'volume_ratio': self.volume_ratio,
            'market_regime': self.market_regime.value
        }

@dataclass
class PortfolioItem:
    symbol: str
    weight: float
    correlation: float