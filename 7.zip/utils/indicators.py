import numpy as np
from typing import List, Dict, Tuple
import logging
from data_models import Candle

# We attempt to import TA-Lib for technical indicator calculations. TA-Lib may not
# be available in all environments (it requires native extensions). If it's
# unavailable, we fall back to implementations using pandas and numpy. These
# implementations provide the basic calculations necessary for EMA, RSI, ATR and
# MACD used within this project.
try:
    import talib  # type: ignore
    _talib_available = True
except ModuleNotFoundError:
    _talib_available = False
    # Fallback using pandas for indicator calculations
    import pandas as pd

    def _ema(arr: np.ndarray, period: int) -> np.ndarray:
        return pd.Series(arr).ewm(span=period, adjust=False).mean().to_numpy()

    def _rsi(arr: np.ndarray, period: int) -> np.ndarray:
        # Calculate price changes
        delta = np.diff(arr)
        # Up and down movements
        up = np.where(delta > 0, delta, 0)
        down = np.where(delta < 0, -delta, 0)
        # Exponential moving averages of ups and downs
        roll_up = pd.Series(up).ewm(span=period, adjust=False).mean()
        roll_down = pd.Series(down).ewm(span=period, adjust=False).mean()
        rs = roll_up / (roll_down + 1e-9)
        rsi = 100 - (100 / (1 + rs))
        # Prepend initial neutral values to match length
        init = np.full(period, 50.0)
        return np.concatenate([init, rsi.to_numpy()])

    def _atr(highs: np.ndarray, lows: np.ndarray, closes: np.ndarray, period: int) -> np.ndarray:
        tr = []
        for i in range(len(highs)):
            if i == 0:
                tr.append(highs[i] - lows[i])
            else:
                tr.append(max(
                    highs[i] - lows[i],
                    abs(highs[i] - closes[i-1]),
                    abs(lows[i] - closes[i-1])
                ))
        tr_series = pd.Series(tr)
        atr = tr_series.rolling(window=period).mean()
        return atr.to_numpy()

    def _macd(arr: np.ndarray, fastperiod: int, slowperiod: int, signalperiod: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        ema_fast = _ema(arr, fastperiod)
        ema_slow = _ema(arr, slowperiod)
        # Align lengths by padding the shorter array
        # (ema_fast and ema_slow share length equal to arr length)
        macd = ema_fast - ema_slow
        signal = pd.Series(macd).ewm(span=signalperiod, adjust=False).mean().to_numpy()
        hist = macd - signal
        return macd, signal, hist

logger = logging.getLogger('FuturesBot')

class TechnicalIndicators:
    # Bộ nhớ cache cho tính toán chỉ báo
    _cache = {}
    _cache_size = 1000
    
    @classmethod
    def calculate_ema(cls, data: List[float], period: int) -> List[float]:
        """
        Tính đường EMA (Exponential Moving Average). Sử dụng TA-Lib nếu
        khả dụng, ngược lại dùng phép tính thay thế bằng pandas.
        """
        if len(data) < period:
            return []
        key = ("ema", period, len(data))
        if key in cls._cache:
            return cls._cache[key]
        arr = np.array(data, dtype=float)
        if _talib_available:
            ema = talib.EMA(arr, timeperiod=period)
            result = ema.tolist()
        else:
            # fallback to pandas implementation
            result = _ema(arr, period).tolist()
        cls._cache[key] = result
        # Giữ cache không vượt quá kích thước tối đa
        if len(cls._cache) > cls._cache_size:
            cls._cache.pop(next(iter(cls._cache)))
        return result
    
    @classmethod
    def calculate_rsi(cls, data: List[float], period: int) -> List[float]:
        """
        Tính chỉ số RSI (Relative Strength Index). Nếu TA-Lib không có sẵn,
        dùng cách tính thủ công với pandas.
        """
        if len(data) < period:
            return []
        key = ("rsi", period, len(data))
        if key in cls._cache:
            return cls._cache[key]
        arr = np.array(data, dtype=float)
        if _talib_available:
            rsi = talib.RSI(arr, timeperiod=period)
            result = rsi.tolist()
        else:
            result = _rsi(arr, period).tolist()
        cls._cache[key] = result
        if len(cls._cache) > cls._cache_size:
            cls._cache.pop(next(iter(cls._cache)))
        return result
    
    @classmethod
    def calculate_atr(cls, candles: List[Candle], period: int) -> List[float]:
        """
        Tính chỉ báo ATR (Average True Range). Nếu TA-Lib không sẵn có,
        dùng phép tính tự triển khai.
        """
        if len(candles) < period:
            return []
        key = ("atr", period, len(candles))
        if key in cls._cache:
            return cls._cache[key]
        highs = np.array([c.high for c in candles], dtype=float)
        lows = np.array([c.low for c in candles], dtype=float)
        closes = np.array([c.close for c in candles], dtype=float)
        if _talib_available:
            atr = talib.ATR(highs, lows, closes, timeperiod=period).tolist()
        else:
            atr = _atr(highs, lows, closes, period).tolist()
        cls._cache[key] = atr
        if len(cls._cache) > cls._cache_size:
            cls._cache.pop(next(iter(cls._cache)))
        return atr
    
    @classmethod
    def calculate_macd(cls, data: List[float], fast: int, slow: int, signal: int) -> Tuple[List[float], List[float], List[float]]:
        """
        Tính MACD (Moving Average Convergence Divergence) và đường tín hiệu.
        Nếu TA-Lib không sẵn có, sử dụng cách tính thủ công.
        """
        if len(data) < slow:
            return [], [], []
        key = ("macd", fast, slow, signal, len(data))
        if key in cls._cache:
            return cls._cache[key]
        arr = np.array(data, dtype=float)
        if _talib_available:
            macd, macd_signal, macd_hist = talib.MACD(arr, fastperiod=fast, slowperiod=slow, signalperiod=signal)
            result = (macd.tolist(), macd_signal.tolist(), macd_hist.tolist())
        else:
            macd_arr, signal_arr, hist_arr = _macd(arr, fast, slow, signal)
            result = (macd_arr.tolist(), signal_arr.tolist(), hist_arr.tolist())
        cls._cache[key] = result
        if len(cls._cache) > cls._cache_size:
            cls._cache.pop(next(iter(cls._cache)))
        return result