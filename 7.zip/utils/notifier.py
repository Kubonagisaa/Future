"""
Compatibility shim for the notifier module.

The original file defining the notification classes was named
``notifer.py`` (note the missing 'i'), but other modules import
``utils.notifier``. To prevent a ``ModuleNotFoundError``, this module
re-exports the classes from ``notifer.py``. If you wish to add new
notification backends or change the naming, please update both files
consistently.
"""

from .notifer import *  # noqa: F401,F403