import threading
import logging

# Flask is an optional dependency used to serve the dashboard. In
# environments where Flask is not installed, we provide a fallback to
# disable the dashboard while allowing the rest of the bot to run.
try:
    from flask import Flask, jsonify, render_template  # type: ignore
    _flask_available = True
except ModuleNotFoundError:
    _flask_available = False
    # Define dummy stand‑ins so that type checkers don't fail. They will not
    # actually be used when Flask is unavailable.
    Flask = None  # type: ignore
    jsonify = lambda *args, **kwargs: None  # type: ignore
    render_template = lambda *args, **kwargs: None  # type: ignore

from config import Config
logger = logging.getLogger('FuturesBot')

class DashboardServer:
    def __init__(self, config: Config, bot: 'FuturesTradingBot'):
        self.config = config
        self.bot = bot
        # Only create a Flask app if the dependency is available and the
        # dashboard is enabled. Otherwise we skip initialization.
        self.thread = None
        if _flask_available and self.config.general.dashboard_enabled:
            self.app = Flask(__name__)
        else:
            self.app = None
        
        # Only define routes if the app exists
        if self.app is not None:
            @self.app.route('/')
            def index():
                # Trang hiển thị thông tin chung
                return jsonify({"message": "Futures Trading Bot Dashboard"})
            
            @self.app.route('/status')
            def status():
                # Trả về trạng thái bot và các vị thế hiện tại
                positions = {
                    symbol: {
                        "side": pos.side.value,
                        "size": pos.size,
                        "entry_price": pos.entry_price,
                        "stop_loss": pos.stop_loss,
                        "take_profit": pos.take_profit
                    }
                    for symbol, pos in self.bot.active_positions.items()
                }
                return jsonify({
                    "running": self.bot.running,
                    "equity": self.bot.exchange.equity,
                    "active_positions": positions
                })
            
            @self.app.route('/metrics')
            def metrics():
                # Trả về các chỉ số hiệu suất (nếu có)
                return jsonify({
                    "daily_trade_count": self.bot.risk_manager.daily_trade_count,
                    "current_drawdown_pct": self.bot.risk_manager.current_drawdown,
                    "consecutive_losses": self.bot.risk_manager.consecutive_losses
                })
        
    def start(self):
        # Only start the dashboard if the Flask app is available and dashboard is enabled
        if self.app is None:
            logger.info("Dashboard is disabled or Flask is not available; skipping dashboard startup.")
            return
        if not self.thread:
            self.thread = threading.Thread(target=self.app.run, kwargs={"port": self.config.general.dashboard_port})
            self.thread.daemon = True
            self.thread.start()
            logger.info(f"Dashboard started on port {self.config.general.dashboard_port}")