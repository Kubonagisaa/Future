import aiohttp
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, Any, List
from config import Config
from data_models import PositionSide

logger = logging.getLogger('FuturesBot')

class NotificationError(Exception):
    """Ngoại lệ tùy chỉnh cho lỗi thông báo"""
    pass

class BaseNotifier:
    """Lớp cơ sở cho tất cả các trình thông báo"""
    def __init__(self, config: Config):
        self.config = config

class TelegramNotifier(BaseNotifier):
    def __init__(self, config: Config):
        super().__init__(config)
        self.enabled = config.notification.telegram_enabled
        self.bot_token = config.notification.telegram_bot_token
        self.chat_id = config.notification.telegram_chat_id

    async def send_message(self, message: str):
        if not self.enabled or not self.bot_token or not self.chat_id:
            return
        try:
            async with aiohttp.ClientSession() as session:
                url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
                data = {"chat_id": self.chat_id, "text": message}
                await session.post(url, data=data)
        except Exception as e:
            logger.error(f"Failed to send telegram message: {e}")
            raise NotificationError(f"Telegram error: {e}")

    async def notify_trade(self, side: PositionSide, symbol: str, size: float, price: float, strategy: str):
        if not self.enabled:
            return
        direction = "mua" if side == PositionSide.LONG else "bán"
        message = f"Vừa vào lệnh {direction} {symbol} - khối lượng: {size}, giá: {price}, chiến lược: {strategy}"
        await self.send_message(message)

    async def notify_funding(self, symbol: str, amount: float, side: PositionSide):
        if not self.enabled:
            return
        direction = "LONG" if side == PositionSide.LONG else "SHORT"
        message = f"Funding applied cho vị thế {direction} {symbol}: {amount:.4f} USDT"
        await self.send_message(message)

    async def notify_trailing_update(self, symbol: str, new_stop: float, new_tp: float):
        if not self.enabled:
            return
        message = f"Cập nhật trailing cho {symbol}: Stop={new_stop:.4f}, TP={new_tp:.4f}"
        await self.send_message(message)

    async def notify_shutdown(self, reason: str, equity: float):
        if not self.enabled:
            return
        message = f"Bot dừng hoạt động. Lý do: {reason}. Equity hiện tại: {equity:.2f} USDT"
        await self.send_message(message)

    async def notify_daily_report(self, trades_count: int, daily_pnl: float, win_rate: float):
        if not self.enabled:
            return
        message = (f"Báo cáo giao dịch hôm nay: Số lệnh = {trades_count}, "
                   f"P/L = {daily_pnl:.2f} USDT, Tỷ lệ thắng = {win_rate:.2f}%")
        await self.send_message(message)