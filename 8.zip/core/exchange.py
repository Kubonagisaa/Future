"""
Futures exchange abstraction for the trading bot.

This module defines a ``FuturesExchange`` class that wraps around ccxt's
Binance futures implementation. When ccxt is unavailable or fails to
initialise, a stub mode is used instead which generates synthetic data
and simulates order execution. This allows the bot to run in paper
trading or testing environments without requiring external network
dependencies.

The exchange exposes methods for fetching OHLCV data, setting leverage,
applying funding, updating equity, checking open orders, creating and
closing positions, and cancelling orders. Additional helper methods
provide access to current positions and prices.
"""

from __future__ import annotations

import time
import logging
from typing import Dict, List, Optional, Any

try:
    # Attempt to import the asynchronous ccxt implementation. If this
    # import fails (e.g. ccxt is not installed in the environment), we
    # fall back to a stub exchange implementation later.
    import ccxt.async_support as ccxt  # type: ignore
except Exception:
    ccxt = None

from config import Config
from data_models import Candle, Position, Order, OrderType, PositionSide, OrderStatus
from utils.notifer import TelegramNotifier


logger = logging.getLogger("FuturesBot")


class ExchangeError(Exception):
    """Custom exception for exchange-related errors."""

    pass


class FuturesExchange:
    """
    Wrapper around a futures trading exchange. When ccxt is available
    and initialises successfully, this class forwards calls to the
    underlying ccxt exchange. Otherwise, it operates in a stub mode
    where market data and order execution are simulated.

    :param config: Bot configuration
    :param notifier: Optional notifier for sending error messages
    """

    def __init__(self, config: Config, notifier: Optional[TelegramNotifier] = None) -> None:
        self.config = config
        self.notifier = notifier
        self.exchange = None
        self.positions: Dict[str, Position] = {}
        self.open_orders: Dict[str, Order] = {}
        self.initial_balance: float = config.trading.initial_balance
        self.equity: float = config.trading.initial_balance
        self.circuit_breaker_enabled: bool = False
        self.circuit_breaker_trigger_time: float = 0.0
        self.last_circuit_breaker_time: float = 0.0

        # Initialise the ccxt exchange if possible. We support multiple
        # exchanges by reading the desired exchange name from the
        # configuration. The list of exchanges is defined in
        # ``config.api.exchanges`` and a primary exchange can be set via
        # ``config.api.primary_exchange`` or the deprecated ``EXCHANGE`` env.
        if ccxt is not None:
            # Determine which exchange to use. Lowercase all values for
            # consistency. If no primary exchange is specified, fall back
            # to the first entry in the exchanges list (default ``binance``).
            exchange_name: str = (
                config.api.primary_exchange
                if config.api.primary_exchange
                else (config.api.exchanges[0] if config.api.exchanges else "binance")
            ).lower()

            try:
                # Common options: API credentials and rate limiting. Many
                # exchanges require a ``defaultType`` option to specify
                # whether we are trading futures, swaps or spot. We set
                # ``future`` by default but override it for exchanges that
                # require a different value (e.g. mexc3 uses swap). Users
                # can adjust this by specifying a different exchange
                # identifier in the EXCHANGES variable (e.g. ``mexc3``).
                options: Dict[str, Any] = {
                    "apiKey": config.api.key,
                    "secret": config.api.secret,
                    "enableRateLimit": True,
                }
                # Determine appropriate defaultType per exchange
                default_type = "future"
                # MEXC uses swap endpoints for perpetual contracts
                if exchange_name in {"mexc", "mexc3"}:
                    default_type = "swap"
                # Bybit linear futures use "linear"
                elif exchange_name in {"bybit", "bybitusdt"}:
                    default_type = "linear"
                # OKX uses swap endpoints for USDT perpetual
                elif exchange_name in {"okx"}:
                    default_type = "swap"
                # Bitget uses swap for USDT-M perpetual
                elif exchange_name in {"bitget"}:
                    default_type = "swap"
                # KuCoin futures (USDT-M) use "future"
                elif exchange_name in {"kucoin"}:
                    default_type = "future"
                # Kraken futures (linear) use "linear"
                elif exchange_name in {"kraken"}:
                    default_type = "linear"
                # Huobi (HTX) linear futures use "linear"
                elif exchange_name in {"huobi", "htx"}:
                    default_type = "linear"
                # Bitfinex futures use "future"
                elif exchange_name in {"bitfinex"}:
                    default_type = "future"
                # Gate.io uses swap
                elif exchange_name in {"gate", "gateio"}:
                    default_type = "swap"
                # BitMEX uses swap for perpetual contracts
                elif exchange_name in {"bitmex"}:
                    default_type = "swap"

                options["options"] = {"defaultType": default_type}

                # Instantiate the exchange using ccxt. Some exchanges
                # (e.g. ``mexc`` vs ``mexc3``) have different class names;
                # attempt to find the provided name first, falling back to
                # a best‑known alternative. If the exchange is unsupported,
                # a runtime error will be raised and we will fall back to
                # stub mode.
                ex_class = None
                # try the provided exchange_name directly
                if hasattr(ccxt, exchange_name):
                    ex_class = getattr(ccxt, exchange_name)
                # for common aliases, map to the appropriate ccxt id
                if ex_class is None:
                    alias_map = {
                        # Normalise MEXC id variations
                        "mexc": "mexc3",
                        "mexc3": "mexc3",
                        # Main default mappings
                        "binance": "binance",
                        "bybit": "bybit",
                        # Additional exchanges
                        "okx": "okx",
                        "bitget": "bitget",
                        "kucoin": "kucoin",
                        "kraken": "kraken",
                        "huobi": "huobi",
                        "htx": "huobi",
                        "bitfinex": "bitfinex",
                        "gate": "gate",
                        "gateio": "gate",
                        "bitmex": "bitmex",
                    }
                    mapped = alias_map.get(exchange_name)
                    if mapped and hasattr(ccxt, mapped):
                        ex_class = getattr(ccxt, mapped)
                if ex_class is None:
                    raise Exception(f"Unsupported exchange '{exchange_name}'")

                # Create the exchange instance
                ex = ex_class(options)
                # Set sandbox (testnet) mode for exchanges that support it
                if config.api.testnet and exchange_name in {"binance", "bybit"}:
                    ex.set_sandbox_mode(True)

                self.exchange = ex
                logger.info("Exchange initialised successfully (%s)", exchange_name)
            except Exception as exc:
                logger.error("Failed to initialise exchange %s: %s", exchange_name, exc)
                self.exchange = None
        else:
            logger.warning(
                "ccxt library not available. Using stubbed exchange with no real connectivity."
            )
            self.exchange = None

    # ------------------------------------------------------------------
    # Market Data

    async def fetch_ohlcv(self, symbol: str, timeframe: str, limit: int) -> List[Candle]:
        """
        Fetch OHLCV (Open-High-Low-Close-Volume) candles for a symbol.
        When running in stub mode, synthetic candle data is generated.

        :param symbol: Trading pair (e.g. "BTC/USDT")
        :param timeframe: Candlestick timeframe (e.g. "5m")
        :param limit: Number of candles to fetch
        :return: List of Candle objects
        """
        if self.exchange is None:
            # Generate dummy candles in stub mode. We simulate a simple
            # upward trend over the requested number of candles.
            candles: List[Candle] = []
            base_price = 100.0
            for i in range(limit):
                ts = int(time.time() * 1000) - (limit - i) * 60_000  # 1 minute per candle
                price = base_price + i
                high = price + 1.0
                low = price - 1.0
                close = price
                volume = 100.0
                candles.append(Candle(ts, price, high, low, close, volume))
            return candles
        try:
            raw = await self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
            return [Candle(*row) for row in raw]
        except Exception as exc:
            logger.error("Failed to fetch OHLCV for %s: %s", symbol, exc)
            if self.notifier:
                await self.notifier.send_message(f"Failed to fetch market data for {symbol}: {exc}")
            return []

    async def get_ohlcv(self, symbol: str, timeframe: str, limit: int = 100) -> List[Candle]:
        """Convenience wrapper around fetch_ohlcv with default limit."""
        return await self.fetch_ohlcv(symbol, timeframe, limit)

    # ------------------------------------------------------------------
    # Account Management

    async def set_leverage(self, symbol: str, leverage: int) -> bool:
        """
        Set leverage for a given trading pair. In stub mode, this simply
        logs the action and returns True.
        """
        # Do not attempt to change leverage when running in paper trading mode.
        # In this mode orders and account changes are simulated only.
        if self.config.general.paper_trading:
            logger.info("Paper trading: pretend to set leverage %d for %s", leverage, symbol)
            return True

        # If we are running without a connected exchange, just log and return.
        if self.exchange is None:
            logger.debug("Stub exchange: set leverage %d for %s", leverage, symbol)
            return True
        try:
            # Determine which exchange is configured to select the appropriate
            # parameters.  MEXC requires openType and positionType parameters.
            exchange_name = (
                self.config.api.primary_exchange
                if self.config.api.primary_exchange
                else (self.config.api.exchanges[0] if self.config.api.exchanges else "binance")
            ).lower()
            # Handle MEXC specific leverage call
            if exchange_name.startswith("mexc"):
                # MEXC expects symbols in the form "BTC/USDT:USDT" instead of "BTC/USDT".
                market_symbol = symbol
                # append colon and quote currency if not provided
                if ":" not in symbol and "/" in symbol:
                    quote = symbol.split("/")[1]
                    market_symbol = f"{symbol}:{quote}"
                # Use openType=1 (isolated) and positionType=1 (long) by default.  These
                # parameters are mandatory for MEXC leverage API.  Users can
                # customise these values via code changes or further config if needed.
                params: Dict[str, Any] = {"openType": 1, "positionType": 1}
                await self.exchange.set_leverage(leverage, market_symbol, params)
            else:
                await self.exchange.set_leverage(leverage, symbol)
            logger.info("Leverage set to %d for %s", leverage, symbol)
            return True
        except Exception as exc:
            logger.error("Failed to set leverage for %s: %s", symbol, exc)
            if self.notifier:
                await self.notifier.send_message(f"Failed to set leverage for {symbol}: {exc}")
            return False

    async def apply_funding(self) -> None:
        """
        Apply funding payments to open positions. In paper trading mode
        without a real exchange, funding is simulated by adjusting the
        bot's equity based on a small funding rate.
        """
        if not self.config.general.paper_trading:
            return
        now = time.time()
        for symbol, pos in list(self.positions.items()):
            # Apply funding every 8 hours
            if now - pos.last_funding_time >= 8 * 60 * 60:
                funding_rate = 0.0001  # simulated funding rate
                funding_amount = pos.size * pos.entry_price * funding_rate
                if pos.side == PositionSide.LONG:
                    self.equity -= funding_amount
                else:
                    self.equity += funding_amount
                pos.last_funding_time = now
                logger.info("Funding applied for %s: %.4f", symbol, funding_amount)
                if self.notifier:
                    await self.notifier.notify_funding(symbol, funding_amount, pos.side)

    async def update_equity(self) -> None:
        """
        Update the account's equity from the exchange. In stub mode,
        equity is left unchanged.
        """
        if self.exchange is None:
            return
        try:
            balance = await self.exchange.fetch_balance()
            total = balance.get("total", {})
            if "USDT" in total:
                self.equity = float(total["USDT"])
            logger.debug("Equity updated: %.2f", self.equity)
        except Exception as exc:
            logger.error("Failed to update equity: %s", exc)
            if self.notifier:
                await self.notifier.send_message(f"Failed to update equity: {exc}")

    # ------------------------------------------------------------------
    # Order Management

    async def check_open_orders(self, symbol: str) -> None:
        """
        Update statuses of open orders for a given symbol. In stub mode,
        orders are immediately marked as filled.
        """
        if self.exchange is None:
            for oid, order in list(self.open_orders.items()):
                if order.symbol == symbol:
                    order.status = OrderStatus.FILLED
                    order.filled = order.amount
                    order.remaining = 0.0
                    del self.open_orders[oid]
            return
        try:
            raw_orders = await self.exchange.fetch_open_orders(symbol)
            for raw in raw_orders:
                oid = raw.get("id")
                if oid not in self.open_orders:
                    continue
                our = self.open_orders[oid]
                status = raw.get("status")
                if status == "closed":
                    our.status = OrderStatus.FILLED
                    our.filled = float(raw.get("filled", our.amount))
                    our.remaining = float(raw.get("remaining", 0.0))
                    del self.open_orders[oid]
                    logger.info("Order %s for %s filled", oid, symbol)
                elif status == "canceled":
                    our.status = OrderStatus.CANCELLED
                    del self.open_orders[oid]
                    logger.info("Order %s for %s canceled", oid, symbol)
        except Exception as exc:
            logger.error("Error checking open orders for %s: %s", symbol, exc)

    async def create_order(
        self,
        symbol: str,
        order_type: OrderType,
        side: PositionSide,
        amount: float,
        price: Optional[float] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Optional[Order]:
        """
        Create a new order. In stub mode, an order object is created
        locally and marked as filled immediately.

        :return: Order object or None on failure
        """
        if self.exchange is None:
            oid = f"stub_{int(time.time() * 1000)}"
            exec_price = price if price is not None else 0.0
            order = Order(
                id=oid,
                symbol=symbol,
                type=order_type,
                side=side,
                amount=amount,
                price=exec_price,
                status=OrderStatus.FILLED,
                timestamp=int(time.time() * 1000),
                params=params or {},
                filled=amount,
                remaining=0.0,
            )
            self.open_orders[oid] = order
            logger.info("Stub order created %s for %s amount %.6f", oid, symbol, amount)
            return order
        try:
            side_str = "buy" if side == PositionSide.LONG else "sell"
            type_str = order_type.value.lower()
            args: Dict[str, Any] = {
                "symbol": symbol,
                "type": type_str,
                "side": side_str,
                "amount": amount,
            }
            if price is not None:
                args["price"] = price
            if params:
                args["params"] = params
            raw = await self.exchange.create_order(**args)
            oprice = float(raw.get("price") or raw.get("average") or (price or 0.0))
            order = Order(
                id=raw["id"],
                symbol=symbol,
                type=order_type,
                side=side,
                amount=amount,
                price=oprice,
                status=OrderStatus.OPEN,
                timestamp=int(time.time() * 1000),
                params=params or {},
                filled=float(raw.get("filled", 0.0)),
                remaining=float(raw.get("remaining", amount)),
            )
            self.open_orders[order.id] = order
            logger.info("Created order %s for %s", order.id, symbol)
            return order
        except Exception as exc:
            logger.error("Failed to create order for %s: %s", symbol, exc)
            if self.notifier:
                await self.notifier.send_message(f"Failed to create order for {symbol}: {exc}")
            return None

    async def close_position(
        self,
        symbol: str,
        side: PositionSide,
        amount: float,
        reason: str = "",
    ) -> bool:
        """
        Close an existing position by placing an opposing market order. In
        stub mode, the position is removed from memory without sending
        any order to an exchange.
        """
        if self.exchange is None:
            pos = self.positions.get(symbol)
            if pos is not None:
                if amount >= pos.size:
                    del self.positions[symbol]
                else:
                    pos.size -= amount
            logger.info("Stub closed position %s size %.6f reason %s", symbol, amount, reason)
            return True
        try:
            close_side = "sell" if side == PositionSide.LONG else "buy"
            raw = await self.exchange.create_order(
                symbol=symbol,
                type="market",
                side=close_side,
                amount=amount,
            )
            if raw and raw.get("status") == "closed":
                pos = self.positions.get(symbol)
                if pos is not None:
                    if amount >= pos.size:
                        del self.positions[symbol]
                    else:
                        pos.size -= amount
                logger.info("Closed position for %s size %.6f reason %s", symbol, amount, reason)
                return True
            return False
        except Exception as exc:
            logger.error("Failed to close position for %s: %s", symbol, exc)
            if self.notifier:
                await self.notifier.send_message(f"Failed to close position for {symbol}: {exc}")
            return False

    async def load_market_info(self) -> None:
        """Load market information such as limits and precision."""
        if self.exchange is None:
            return
        try:
            await self.exchange.load_markets()
            logger.info("Market info loaded")
        except Exception as exc:
            logger.error("Failed to load market info: %s", exc)

    # ------------------------------------------------------------------
    # Helpers

    async def get_position(self, symbol: str) -> Optional[Position]:
        """Return the current position for a symbol, if any."""
        return self.positions.get(symbol)

    async def get_current_price(self, symbol: str) -> float:
        """
        Retrieve the latest price. In stub mode, use the entry price
        recorded in the position or return 0.0 if no position exists.
        """
        pos = self.positions.get(symbol)
        if pos is not None:
            return pos.entry_price
        return 0.0

    async def check_circuit_breaker(self, symbol: str, candles: List[Candle]) -> None:
        """
        Placeholder for circuit breaker logic. Currently no-op.
        """
        return

    async def cancel_order(self, order_id: str) -> bool:
        """
        Cancel an open order. In stub mode, remove the order from memory.
        If a real exchange is available, forward the cancellation request
        to the exchange.
        """
        if order_id in self.open_orders:
            del self.open_orders[order_id]
            logger.info("Canceled local order %s", order_id)
            return True
        if self.exchange is not None:
            try:
                await self.exchange.cancel_order(order_id)
                logger.info("Canceled exchange order %s", order_id)
                return True
            except Exception:
                logger.error("Failed to cancel order %s on exchange", order_id)
                return False
        return False